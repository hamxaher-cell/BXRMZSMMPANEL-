// FIREBASE CONFIGURATION & INITIALIZATION
const firebaseConfig = {
  apiKey: "AIzaSyDqPQcvlQom1K9MxHeYF0986axOwZpzshY",
  authDomain: "bxrmsz.firebaseapp.com",
  databaseURL: "https://bxrmsz-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "bxrmsz",
  storageBucket: "bxrmsz.firebasestorage.app",
  messagingSenderId: "893098186529",
  appId: "1:893098186529:web:5b5977266447b37cf09060",
  measurementId: "G-7DXR2NSS8L"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Export Auth & DB globally
const auth = firebase.auth();
const db = firebase.database();

// ImgBB API Key (Global)
const IMGBB_KEY = "172dabb7ec93ead71d6b9e5631f3155d";

console.log("Firebase Connected via firebase.js");