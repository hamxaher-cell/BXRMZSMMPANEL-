BXRMSZ SHOP - MANUAL UPI PAYMENT

1. Upload all files in this folder to the same directory on your hosting account.
2. Keep bxrmsz-payment-qr.jpg beside addfunds.html.
3. Customers open Add Funds, enter an amount, scan the QR, then submit the UTR and payment screenshot.
4. Admin opens the Payments tab in adminpanel.html, verifies the UTR in the UPI app/bank account, then approves or rejects the request.
5. Automatic payment-gateway PHP endpoints are not included in this manual-payment package.

UPI ID encoded in the supplied QR: mahirxd@fam

SECURITY NOTE:
Configure Firebase Realtime Database security rules so users can only create their own payment requests and cannot write wallet balances or approve requests. Only trusted admin accounts should be allowed to approve/reject and update balances. Rotate any API tokens/secrets that were exposed in earlier shared ZIPs.
